using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class UIControllerDemo : MonoBehaviour
{
    public Transform startingDisplay;
    public Vector2[] informPanelPositions;
    public string[] informPanelData;
    public Transform loopDisplay;

    public TextMeshProUGUI informPanelPrefab;
    public float fontSize;
    public TMP_FontAsset font;

    void Start()
    {
        for (int i = 0; i < informPanelPositions.Length; i++)
        {
            informPanelPrefab.text = informPanelData[i];
            informPanelPrefab.font = font;
            informPanelPrefab.fontSize = fontSize;
            informPanelPrefab.alignment = TextAlignmentOptions.Center;
            GameObject go = Instantiate(informPanelPrefab.transform.parent.gameObject, startingDisplay);
            RectTransform rect = go.GetComponent<RectTransform>();
            rect.localPosition = informPanelPositions[i];
            go.SetActive(true);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}

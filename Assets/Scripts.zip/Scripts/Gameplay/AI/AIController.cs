using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class AIController : MonoBehaviour
{
    protected enum typeCharacter { building, verticle, character }
    protected typeCharacter type;

    protected NavMeshAgent agent;
    public Transform guide;
    protected List<Transform> guideFull = new List<Transform>();
    public Transform targetPosition;
    protected Vector3 currentPosition;

    public int enemyCount;

    protected GameObject good;
    protected ParticleSystem destroyed;
    protected bool destroyedState;

    protected void StartSetup()
    {
        if (type == typeCharacter.verticle || type == typeCharacter.building)
        {
            destroyed = transform.GetChild(0).GetComponent<ParticleSystem>();
            good = transform.GetChild(1).gameObject;
            destroyed.Stop(true);
        }
        if (type == typeCharacter.verticle || type == typeCharacter.character)
        {
            agent = GetComponent<NavMeshAgent>();
            for (int i = 0; i < guide.childCount; i++)
            {
                guideFull.Add(guide.GetChild(i));
            }
            if (targetPosition == null)
                GetStartPoint();
            else
            {
                agent.SetDestination(targetPosition.position);
                StartCoroutine(CheckDistance());
            }
        }
    }

    void GetStartPoint() 
    {
        targetPosition = guideFull[0].transform;
        for (int i = 0; i < guideFull.Count; i++)
        {
            if(Vector3.Distance(transform.position, guideFull[i].transform.position) < Vector3.Distance(transform.position, targetPosition.position)) 
            {
                targetPosition = guideFull[i].transform;
            }
        }
        agent.SetDestination(targetPosition.position);
        StartCoroutine(CheckDistance()); 
        Debug.Log($"{gameObject.name} target to {targetPosition.name} positions {targetPosition.position}");
    }

    protected void GetNextPoint() 
    {
        for (int i = 0; i < guideFull.Count; i++)
        {
            if (targetPosition == guideFull[i]) 
            {
                if (i < guideFull.Count - 1)
                    targetPosition = guideFull[++i];
                else
                    targetPosition = guideFull[0];
                break;
            }
        }
        agent.SetDestination(targetPosition.position);

        Debug.Log($"{gameObject.name} target to {targetPosition.name} positions {targetPosition.position}");
    }

    protected IEnumerator CheckDistance()
    {
        currentPosition = transform.position;
        yield return new WaitForSeconds(0.3f);
        if (Vector3.Distance(currentPosition, targetPosition.position) > 0.6f)
        {
            StartCoroutine(CheckDistance());
        }
        else
        {
            GetNextPoint();
            yield return new WaitForSeconds(Random.Range(0.5f, 0.75f));
            StartCoroutine(CheckDistance());
        }
    }

    //protected void Retarget()
    //{
    //    //targetPosition = Vector3.zero;
    //    float randomDistance = Random.Range(-50f, 50f);
    //    //targetPosition = transform.position + new Vector3(randomDistance, transform.position.y, randomDistance);
    //    StartCoroutine(CheckDistance());
    //    //agent.SetDestination(targetPosition);
    //}

    public void Destroying()
    {
        if (!destroyedState)
        {
            destroyedState = true;
            Destroy(agent);
            //agent.isStopped = true;
            GameController.Instance.AddPiggydog(enemyCount);
            if (destroyed != null)
            {
                destroyed.gameObject.SetActive(true);
                destroyed.Play(true);
                good.SetActive(false);
            }
        }
    }
}
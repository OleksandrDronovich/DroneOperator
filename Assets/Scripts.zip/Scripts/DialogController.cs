using TMPro;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections;
using System.Collections.Generic;

[System.Serializable]
public enum ButtonPosition
{
    right,
    bottom
}

[System.Serializable]
public enum WindowType
{
    top,
    center,
    bottom
}

[System.Serializable]
public class ButtonContent
{
    public string text;
    public Color color;
    public Button.ButtonClickedEvent onClick;
}

[System.Serializable]
public class DialogContent 
{
    public WindowType windowType;
    public string windowText;
    public bool rotateIcon;
    public bool showField;
    public ButtonPosition buttonPosition;
    public ButtonContent[] buttonContent;
}

[System.Serializable]
public class DialogUIContent
{
    public WindowType type;
    public RectTransform[] typeParent;
    public RectTransform window;
    public TextMeshProUGUI dialogText;
    public Image character;
    public InputField field;

    [Header("Button")]
    public GameObject baseObject;
    public Button baseButton;
    public Image baseImage;
    public TextMeshProUGUI buttonText;
    public RectTransform[] buttonParents;

    public void SetWindowData(DialogContent content, Action destroy, Action instantiate) 
    {
        RectTransform dialogRect = dialogText.rectTransform;

        destroy.Invoke();

        for (int i = 0; i < content.buttonContent.Length; i++)
        {
            baseImage.color = content.buttonContent[i].color;
            baseButton.onClick = content.buttonContent[i].onClick;
            buttonText.text = content.buttonContent[i].text;

            instantiate.Invoke();
        }

        if (content.rotateIcon)
            character.rectTransform.localScale = new Vector3(-1, 1, 1);
        else
            character.rectTransform.localScale = Vector3.one;


        float windowX = window.sizeDelta.x / 3 * 2;
        float windowY = window.sizeDelta.y / 2;

        

        if (content.showField)
        {
            field.gameObject.SetActive(true);
            dialogRect.localPosition = new Vector2(dialogRect.localPosition.x, windowY - windowY / 2 + 5);
            dialogRect.sizeDelta = new Vector2(dialogRect.sizeDelta.x, windowY - 30);
        }
        else
        {
            field.gameObject.SetActive(false);
            dialogRect.localPosition = new Vector2(dialogRect.localPosition.x, 0);
            dialogRect.sizeDelta = new Vector2(dialogRect.sizeDelta.x, window.sizeDelta.y - 60);
        }
        field.text = "";

        dialogText.text = content.windowText;

        window.SetParent(typeParent[(int)content.windowType]);

        if (!window.gameObject.activeSelf)
            window.gameObject.SetActive(true);
    }
}

public class DialogController : MonoBehaviour
{
    public static DialogController Instance;

    public DialogUIContent currentUIContent;

    private DialogContent currentContent;
    private void Awake()
    {
        Instance = this;
    }

    public void SetContent(DialogContent value) 
    {
        currentContent = value;
        currentUIContent.SetWindowData(value, DestroyButton, InstantiateButtons);
    }

    public void DestroyButton() 
    {
        for (int i = 0; i < currentUIContent.buttonParents.Length; i++)
        {
            if (currentUIContent.buttonParents[i].childCount > 0)
            {
                for (int c = currentUIContent.buttonParents[i].childCount; c > 0; c--)
                {
                    Destroy(currentUIContent.buttonParents[i].GetChild(c - 1).gameObject);
                }
            }
        }
    }

    public void InstantiateButtons() 
    {
        Instantiate(currentUIContent.baseObject, currentUIContent.buttonParents[(int)currentContent.buttonPosition]).SetActive(true);
    }

    public void UpdateContentText(string value) 
    {
        currentContent.windowText = value;
        SetContent(currentContent);
    }

    public void SetCharacterIcon(Sprite value)
    {
        currentUIContent.character.sprite = value;
    }

    public string GetInputData() 
    {
        return currentUIContent.field.text;
    }

    public void HideWindow() 
    {
        currentUIContent.window.gameObject.SetActive(false);
    }
}
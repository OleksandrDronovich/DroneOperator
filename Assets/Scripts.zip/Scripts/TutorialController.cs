using System.Collections;
using UnityEngine;

public class TutorialController : MonoBehaviour
{
    public Sprite characterImage;
    public DialogContent[] content;
    int currentTextShow;

    public void ShowNextText()
    {
        if (content.Length > currentTextShow + 1)
        {
            currentTextShow++;
            DialogController.Instance.SetContent(content[currentTextShow]);
        }
        else
        {
            DialogController.Instance.HideWindow();
        }
    }

    void Start()
    {
        if (PlayerPrefs.HasKey("Tutor"))
        {
            EndTutorial();
        }
        DialogController.Instance.SetContent(content[currentTextShow]);
        DialogController.Instance.SetCharacterIcon(characterImage);
    }

    public void Play() 
    {
        Time.timeScale = 1;
    }

    public void Pause() 
    {
        Time.timeScale = 0;
    }

    public void StepTutorial(float waitingTime) 
    {
        StartCoroutine(NextStep(waitingTime));
    }

    IEnumerator NextStep(float value) 
    {
        yield return new WaitForSeconds(value);
        Pause();
        ShowNextText();
    }

    public void EndTutorial() 
    {
        LoadingDisplayController.Instance.ShowDiaplay(10);
        Play();
        PlayerPrefs.SetInt("Tutor", 1);
        UnityEngine.SceneManagement.SceneManager.LoadScene(1);
    }

    public void SetNickname() 
    {
        if (DialogController.Instance.GetInputData().Length > 3)
        {
            DataController.Instance.UpdateNickname(DialogController.Instance.GetInputData());
            ShowNextText();
        }
        else 
        {
            DialogController.Instance.UpdateContentText("���� �����, ����� �� ����!");
        }
    }
}
using System.Collections;
using System.Net;
using System.Net.NetworkInformation;
using UnityEngine;

public class SaveLoadController<T>
{
    public T LoadData(string saveName)
    {
        string json = PlayerPrefs.GetString(saveName);
        Debug.Log($"Load {json}");
        return JsonUtility.FromJson<T>(json);
    }

    public void SaveData(T data, string saveName)
    {
        string json = JsonUtility.ToJson(data);

        PlayerPrefs.SetString(saveName, json);
        Debug.Log($"Save {json}");
    }

}

[System.Serializable]
public class Data 
{
    public string nickname;
    public int money;
    public int maxKill;
}

public class DataController : MonoBehaviour
{
    public static DataController Instance;
    public Data data;
    public bool isInternetConnection;
    public SaveLoadController<Data> _data = new SaveLoadController<Data>();
    IEnumerator InternetChecker() 
    {
        yield return new WaitForSeconds(10);
        isInternetConnection = PingTest();
        StartCoroutine(InternetChecker()); 
    }

    public bool PingTest()
    {
        System.Net.NetworkInformation.Ping ping = new System.Net.NetworkInformation.Ping();

        PingReply pingStatus = ping.Send(IPAddress.Parse("8.8.8.8"));

        if (pingStatus.Status == IPStatus.Success)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    void Awake()
    {
        Instance = this;
        if (PlayerPrefs.HasKey("AccountData"))
            data = _data.LoadData("AccountData");

        StartCoroutine(InternetChecker());
    }

    private void Start()
    {
        //if(MenuUIController.Instance != null)

    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
            _data.SaveData(data, "AccountData");
    }

    public void UpdateNickname(string value)
    {
        data.nickname = value;
        _data.SaveData(data, "AccountData");
    }

    public void UpdateMoney(int value)
    {
        data.money = value;
        _data.SaveData(data, "AccountData");
    }

    public void UpdateMaxKill(int value)
    {
        data.maxKill = value;
        _data.SaveData(data, "AccountData");
    }
}
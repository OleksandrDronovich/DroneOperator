using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIBuildingController : AIController
{
    public GameObject warrior;
    [Range(1, 10)]
    public int savedCharacters;
    public Transform[] spawnedPosition;
    // Start is called before the first frame update
    void Awake()
    {
        type = typeCharacter.building;
        StartSetup();
        savedCharacters = Random.Range(0, 5);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Destroy() 
    {
        for (int i = 0; i < savedCharacters; i++)
        {
            Instantiate(warrior, spawnedPosition[Random.Range(0, spawnedPosition.Length)].position, Quaternion.identity);
        }
        Destroying();
    }
}

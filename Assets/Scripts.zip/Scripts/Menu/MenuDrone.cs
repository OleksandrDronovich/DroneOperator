using System.Collections;
using UnityEngine;

public class MenuDrone : MonoBehaviour
{

    public UpdateUIInfo currentInfo;

    private void Awake()
    {

    }

    public void ShowZoom()
    {
        MenuUIController.Instance.byeButton.onClick.AddListener(() => MenuController.Instance.AddZoomLevel());
    }

    public void ShowBattery()
    {
        MenuUIController.Instance.byeButton.onClick.AddListener(() => MenuController.Instance.AddBatteryLevel());
    }

    public void ShowTop()
    {
        MenuUIController.Instance.byeButton.onClick.AddListener(() => MenuController.Instance.AddMovingLevel());
    }

    public void ShowManipulators() 
    {
        MenuUIController.Instance.byeButton.onClick.AddListener(() => MenuController.Instance.AddShootingLevel());
    }

    public void ShowBaseUpgrade() 
    {
        
    }

    public void HideBaseUpgrade() 
    {
        
    }

    public void OnMouseDown()
    { 
        ShowBattery();  
    }
}
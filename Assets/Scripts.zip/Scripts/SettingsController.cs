using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SettingsData 
{
    public float music;
    public float sound;
    public bool vibration;
}

public class SettingsController : MonoBehaviour
{
    private SaveLoadController<SettingsData> sdData = new SaveLoadController<SettingsData>();

    private SettingsData sd;

    public Slider musicSlider;
    public Text musicText;

    public Slider soundSlider;
    public Text soundText;


    public Toggle vibrationToggle;

    public void SetMusic() 
    {
        sd.music = musicSlider.value;
        musicText.text = (sd.music * 100).ToString("f0");
    }

    public void SetSound()
    {
        sd.sound = soundSlider.value;
        soundText.text = (sd.sound * 100).ToString("f0");
        
    }

    public void Open() 
    {
        sd = sdData.LoadData("Settings");

        musicSlider.value = sd.music;
        soundSlider.value = sd.sound;

        SetMusic();
        SetSound();
    }

    public void Close()
    {
        sdData.SaveData(sd, "Settings");
    }
}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//
public class AIVerticleController : AIController
{
    void Awake()
    {
        type = typeCharacter.verticle;
        StartSetup();
        destroyed = transform.GetChild(0).GetComponent<ParticleSystem>();
        good = transform.GetChild(1).gameObject;
        destroyed.Stop(true);
    }
}